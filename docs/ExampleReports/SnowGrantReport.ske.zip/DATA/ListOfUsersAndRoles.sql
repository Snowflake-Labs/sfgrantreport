!set output_format=csv
!set header=true
USE ROLE SECURITYADMIN;
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\ROLE\SHOW_ROLES.csv"
SHOW ROLES;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\USER\SHOW_USERS.csv"
SHOW USERS;
!spool off
