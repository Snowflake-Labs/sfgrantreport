!set output_format=csv
!set header=true
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\ACCT\CURRENT_ACCOUNT.csv"
SELECT CURRENT_ACCOUNT() AS CURRENT_ACCOUNT;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\ACCT\CURRENT_REGION.csv"
SELECT CURRENT_REGION() AS CURRENT_REGION;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\ACCT\CURRENT_VERSION.csv"
SELECT CURRENT_VERSION() AS CURRENT_VERSION;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\ACCT\CURRENT_CLIENT.csv"
SELECT CURRENT_CLIENT() AS CURRENT_VERSION;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\CONN\CURRENT_USER.csv"
SELECT CURRENT_USER() AS CURRENT_USER;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\CONN\CURRENT_ROLE.csv"
SELECT CURRENT_ROLE() AS CURRENT_ROLE;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\CONN\CURRENT_WAREHOUSE.csv"
SELECT CURRENT_WAREHOUSE() AS CURRENT_WAREHOUSE;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\CONN\CURRENT_DATABASE.csv"
SELECT CURRENT_DATABASE() AS CURRENT_DATABASE;
!spool off
!spool "C:\snowflake\GrantReport\Reports\ske\DATA\CONN\CURRENT_SCHEMA.csv"
SELECT CURRENT_SCHEMA() AS CURRENT_SCHEMA;
!spool off
